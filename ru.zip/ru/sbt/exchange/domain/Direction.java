package ru.sbt.exchange.domain;

public enum Direction {
    BUY,
    SELL
}
